package com.example.board.domain;

public enum RoleType {
	USER, ADMIN
}
