package com.example.board.exception;

public class BoardException extends RuntimeException {
	
	public BoardException(String msg) {
		super(msg);
	}
	
}
